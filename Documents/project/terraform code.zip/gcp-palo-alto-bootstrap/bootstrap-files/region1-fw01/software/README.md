# Software Directory

This directory contains PAN-OS software upgrades for bootstrap.

## Required Files:

1. **PAN-OS Software** (PanOS_vm-11.2.x)
   - Base PAN-OS software image for VM-Series
   - Download from Palo Alto Customer Support Portal
   - Version: 11.2.x as specified in project requirements

## Download Instructions:

1. Log into https://support.paloaltonetworks.com/
2. Navigate to Updates > Software Updates
3. Filter for "VM-Series" platform
4. Download PAN-OS 11.2.x (or latest compatible version)
5. Place the downloaded file in this directory

## Note:
- Software files are large (typically 500MB+)
- Ensure you have sufficient storage in GCS bucket
- Only include versions you want to auto-upgrade during bootstrap
- File format is typically .tar.gz or similar
