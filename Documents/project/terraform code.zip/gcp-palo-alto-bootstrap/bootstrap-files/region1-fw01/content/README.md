# Content Directory

This directory contains security content updates for PAN-OS:

## Required Files:

1. **Anti-Virus Updates** (panup-all-antivirus-xxxx-xxxx)
   - Latest anti-virus signature database
   - Download from Palo Alto Customer Support Portal

2. **Threat Prevention Content** (panupv2-all-contents-xxxx-xxxx)
   - Application and threat signatures
   - Download from Palo Alto Customer Support Portal

3. **WildFire Updates** (panup-all-wildfire-xxxx-xxxx)
   - WildFire malware signatures
   - Download from Palo Alto Customer Support Portal

## Download Instructions:

1. Log into https://support.paloaltonetworks.com/
2. Navigate to Updates > Content Updates
3. Download the latest versions compatible with PAN-OS 11.2.x
4. Place downloaded files in this directory (no subdirectories)

## Note:
- Files are binary and should not be modified
- Ensure compatibility with your PAN-OS version (11.2.x)
- Update regularly for latest security protection
