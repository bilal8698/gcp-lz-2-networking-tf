# Plugins Directory

This directory contains VM-Series plugins for enhanced functionality.

## Required Files:

1. **VM-Series Plugin** (vm_series-2.0.x)
   - VM-Series specific plugin for GCP
   - Provides enhanced cloud integration capabilities
   - Download from Palo Alto Customer Support Portal

## Download Instructions:

1. Log into https://support.paloaltonetworks.com/
2. Navigate to Updates > VM-Series Plugins
3. Download the latest vm_series plugin compatible with PAN-OS 11.2.x
4. Recommended version: vm_series-2.0.2 or later
5. Place the downloaded file in this directory

## Plugin Features:
- Enhanced GCP metadata support
- Improved cloud-native integrations
- Better performance for virtualized environments
- Required for proper operation in GCP

## Note:
- Plugin must be compatible with your PAN-OS version
- Typically auto-installed during bootstrap
- Version 2.0.2 recommended for PAN-OS 11.2.x
