# License Directory

This directory contains license files and auth codes for Palo Alto firewalls.

## Required Files:

1. **Auth Codes File** (authcodes)
   - Text file containing license authorization codes
   - Format: One auth code per line
   - Obtained from Palo Alto licensing portal

2. **Feature License Keys** (optional - .key files)
   - Advanced Threat Prevention license
   - Advanced WildFire license
   - Advanced URL Filtering license
   - DNS Security license

## Auth Codes File Example:

```
I1234567
I7654321
```

## Instructions:

1. Obtain auth codes from Palo Alto licensing portal
2. Create authcodes file with one code per line
3. Place any .key files (if using) in this directory
4. Update init-cfg.txt with appropriate authcode

## Note:
- Keep license information confidential
- Auth codes are one-time use per device
- Ensure you have sufficient licenses for all firewalls (6 total for 3 regions)
- Add this directory to .gitignore for security
