# Palo Alto VM-Series Bootstrap for Carrier Project

Complete, production-ready bootstrap solution for deploying Palo Alto VM-Series firewalls in GCP with active/active HA across 3 regions.

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Detailed Setup](#detailed-setup)
- [CI/CD Integration](#cicd-integration)
- [Deployment](#deployment)
- [Post-Deployment](#post-deployment)
- [Troubleshooting](#troubleshooting)
- [Maintenance](#maintenance)

## 🎯 Overview

This repository provides Infrastructure as Code (IaC) for deploying **6 Palo Alto VM-Series firewalls** (3 active/active pairs) across 3 GCP regions with:

- ✅ Automated bootstrap using GCS buckets
- ✅ Active/Active HA configuration
- ✅ External and Internal Load Balancers
- ✅ Panorama (StrataCom) integration
- ✅ Carrier mandatory tagging and compliance
- ✅ Complete CI/CD automation with GitHub Actions
- ✅ Security scanning and validation

### Deployment Architecture

| Region | Firewalls | Load Balancers | Zones |
|--------|-----------|----------------|-------|
| us-central1 | 2 (FW-01, FW-02) | 1 External + 1 Internal | us-central1-a, us-central1-b |
| us-east1 | 2 (FW-01, FW-02) | 1 External + 1 Internal | us-east1-b, us-east1-c |
| us-west1 | 2 (FW-01, FW-02) | 1 External + 1 Internal | us-west1-a, us-west1-b |

**Total Resources:**
- 6 VM-Series Firewalls (n2-standard-4)
- 6 Load Balancers (3 External + 3 Internal)
- 3 GCS Bootstrap Buckets
- 1 Service Account
- Firewall Rules + Health Checks

## 🏗 Architecture

### Network Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Internet / External                      │
└──────────────────────┬──────────────────────────────────────┘
                       │
           ┌───────────▼───────────┐
           │  External Load Bal    │  (per region)
           │   (GCP GLB/NLB)       │
           └───────────┬───────────┘
                       │
        ┌──────────────┴──────────────┐
        │                             │
   ┌────▼────┐                   ┌────▼────┐
   │  FW-01  │◄─────HA2/HA3─────►│  FW-02  │
   │(nic0-3) │                   │(nic0-3) │
   └────┬────┘                   └────┬────┘
        │                             │
        └──────────────┬──────────────┘
                       │
           ┌───────────▼───────────┐
           │  Internal Load Bal    │  (per region)
           │   (GCP ILB)           │
           └───────────┬───────────┘
                       │
           ┌───────────▼───────────┐
           │  Internal Workloads   │
           │  (Spoke VPCs)         │
           └───────────────────────┘
```

### Interface Configuration

Each firewall has 4 network interfaces:

| Interface | Name | Purpose | Network |
|-----------|------|---------|---------|
| nic0 | Untrust | External traffic (internet-facing) | global-security-vpc-untrust |
| nic1 | Management | Firewall management + HA1 control link | global-security-vpc-mgmt |
| nic2 | Trust | Internal traffic (to workloads) | global-security-vpc-trust |
| nic3 | HA2/HA3 | Session sync + packet forwarding | global-security-vpc-ha |

**Note:** Management interface swap is performed during deployment (untrust becomes nic0).

### Bootstrap Process Flow

```
1. Terraform Creates GCS Buckets
        ↓
2. Upload Bootstrap Files (init-cfg.txt, content, software, licenses, plugins)
        ↓
3. Terraform Deploys VM-Series Instances
        ↓
4. Instances Boot and Access Bootstrap Bucket via Service Account
        ↓
5. PAN-OS Reads init-cfg.txt and Applies Base Configuration
        ↓
6. Firewall Registers with Panorama (StrataCom)
        ↓
7. Panorama Pushes Full Configuration
        ↓
8. Configure HA Settings via GUI/Panorama
        ↓
9. Traffic Flows through Load Balancers
```

## 📦 Prerequisites

### GCP Requirements

- ✅ GCP Project with billing enabled
- ✅ Required APIs enabled:
  - Compute Engine API
  - Cloud Resource Manager API
  - Cloud Logging API
  - IAM API
  - Cloud Storage API
- ✅ Service account with permissions:
  - `roles/compute.admin`
  - `roles/storage.admin`
  - `roles/iam.serviceAccountAdmin`
  - `roles/logging.admin`
- ✅ Existing VPC networks:
  - `global-security-vpc-mgmt`
  - `global-security-vpc-untrust`
  - `global-security-vpc-trust`
  - `global-security-vpc-ha`

### Palo Alto Requirements

- ✅ Palo Alto Networks support account
- ✅ VM-Series licenses (6 total - one per firewall)
  - BYOL or Flexible Consumption
- ✅ Auth codes for licensing
- ✅ VM Auth Key for Panorama registration
- ✅ Panorama (StrataCom) instance configured
- ✅ Downloaded content updates:
  - Anti-virus signatures
  - Threat prevention content
  - WildFire updates
  - VM-Series plugin (v2.0.2+)
- ✅ PAN-OS 11.2.8 or compatible version

### Local Development Tools

- ✅ Terraform >= 1.5.0
- ✅ gcloud CLI
- ✅ Git
- ✅ Text editor (VS Code recommended)
- ✅ SSH key pair for firewall access

### Carrier Requirements

- ✅ Mandatory tags defined:
  - `cost_center`
  - `owner`
  - `leanix_app_id`
  - `application`
- ✅ Carrier Terraform Scaffold compliance
- ✅ GitHub Enterprise repository
- ✅ Access to Carrier LZ pipeline

## 🚀 Quick Start

### 1. Clone Repository

```bash
git clone https://github.com/carrier/gcp-palo-alto-bootstrap.git
cd gcp-palo-alto-bootstrap
```

### 2. Configure Variables

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values
```

### 3. Initialize Terraform

```bash
terraform init
```

### 4. Plan Deployment

```bash
terraform plan -out=tfplan
```

### 5. Apply Configuration

```bash
terraform apply tfplan
```

### 6. Upload Bootstrap Files

```bash
# Upload to GCS buckets (output from terraform apply)
gsutil -m rsync -r ../bootstrap-files/region1-fw01/ gs://carrier-palo-bootstrap-1/
gsutil -m rsync -r ../bootstrap-files/region1-fw02/ gs://carrier-palo-bootstrap-1/
# Repeat for regions 2 and 3
```

### 7. Monitor Deployment

```bash
# Check firewall instance status
gcloud compute instances list --filter="labels.application=palo-alto-firewall"

# View serial console logs
gcloud compute instances get-serial-port-output carrier-fw-region1-01
```

### 8. Access Firewalls

```bash
# Get management IP addresses
terraform output firewall_pairs

# SSH to firewall
ssh admin@<MANAGEMENT_IP>

# Or access via HTTPS
https://<MANAGEMENT_IP>
```

## 📖 Detailed Setup

### Step 1: Prepare Bootstrap Files

#### 1.1 Update init-cfg.txt Files

For each region and firewall, update the init-cfg.txt files in `bootstrap-files/`:

```bash
# Edit files:
bootstrap-files/region1-fw01/config/init-cfg.txt
bootstrap-files/region1-fw02/config/init-cfg.txt
# ... (repeat for regions 2 and 3)
```

**Update these values:**
- `authcode`: Your actual license authorization code
- `vm-auth-key`: Panorama VM auth key
- `panorama-server`: Your Panorama FQDN or IP
- `ip-address`, `netmask`, `default-gateway`: If using static IPs

#### 1.2 Download Required Files

From Palo Alto Customer Support Portal (https://support.paloaltonetworks.com/):

**Content Updates:**
```bash
# Download and place in bootstrap-files/region1-fw01/content/
- panup-all-antivirus-xxxx-xxxx
- panupv2-all-contents-xxxx-xxxx
- panup-all-wildfire-xxxx-xxxx
```

**Software:**
```bash
# Download and place in bootstrap-files/region1-fw01/software/
- PanOS_vm-11.2.8 (or your desired version)
```

**Plugins:**
```bash
# Download and place in bootstrap-files/region1-fw01/plugins/
- vm_series-2.0.2
```

**Licenses:**
```bash
# Create authcodes file in bootstrap-files/region1-fw01/license/
echo "I1234567" > bootstrap-files/region1-fw01/license/authcodes
# Add one auth code per line for each firewall
```

### Step 2: Configure Terraform Variables

Edit `terraform/terraform.tfvars`:

```hcl
# Project Configuration
project_id     = "carrier-global-security-project"
prefix         = "carrier"
environment    = "prod"

# Carrier Mandatory Tags
cost_center   = "IT-SEC-001"
owner         = "security-team@carrier.com"
leanix_app_id = "APP-PALO-001"

# Firewall Regions (customize as needed)
firewall_regions = {
  "1" = {
    region = "us-central1"
    zones  = ["us-central1-a", "us-central1-b"]
  }
  "2" = {
    region = "us-east1"
    zones  = ["us-east1-b", "us-east1-c"]
  }
  "3" = {
    region = "us-west1"
    zones  = ["us-west1-a", "us-west1-b"]
  }
}

# Panorama Configuration
panorama_server        = "panorama.carrier-global-security.internal"
panorama_server_2      = "panorama-backup.carrier-global-security.internal"
panorama_template_name = "Carrier-VM-Series-Template"

# Network Configuration
management_network = "global-security-vpc-mgmt"
untrust_network    = "global-security-vpc-untrust"
trust_network      = "global-security-vpc-trust"
ha_network         = "global-security-vpc-ha"

# Security
allowed_mgmt_cidrs = ["10.0.0.0/8"]

# SSH Keys
ssh_public_keys = {
  admin = "ssh-rsa AAAAB3NzaC1yc2E... admin@carrier.com"
}
```

**Important:** Never commit sensitive values. Use environment variables:

```bash
export TF_VAR_vm_auth_key="your-vm-auth-key"
export TF_VAR_auth_codes='{"region1-fw01":"I1234567",...}'
```

### Step 3: Enable Required GCP APIs

```bash
gcloud services enable compute.googleapis.com \
  cloudresourcemanager.googleapis.com \
  logging.googleapis.com \
  iam.googleapis.com \
  storage-api.googleapis.com \
  --project=carrier-global-security-project
```

### Step 4: Deploy Infrastructure

```bash
cd terraform

# Initialize Terraform
terraform init

# Validate configuration
terraform validate

# Format code
terraform fmt -recursive

# Plan deployment
terraform plan -out=tfplan

# Review plan output carefully

# Apply configuration
terraform apply tfplan
```

**Expected Duration:** 5-10 minutes for Terraform, 10-15 minutes for firewall bootstrap.

### Step 5: Upload Bootstrap Files to GCS

After Terraform creates the buckets, upload bootstrap files:

```bash
# Get bucket names
terraform output bootstrap_bucket_names

# Upload for each region
for region in 1 2 3; do
  BUCKET="carrier-palo-bootstrap-${region}"
  
  # Upload region-specific files
  for fw in 01 02; do
    gsutil -m rsync -r ../bootstrap-files/region${region}-fw${fw}/ gs://${BUCKET}/
  done
done
```

**Verify uploads:**
```bash
gsutil ls -r gs://carrier-palo-bootstrap-1/
```

### Step 6: Monitor Bootstrap Process

```bash
# Watch instance creation
watch gcloud compute instances list \
  --filter="labels.application=palo-alto-firewall"

# Check serial console logs for bootstrap progress
gcloud compute instances get-serial-port-output carrier-fw-region1-01 \
  --zone=us-central1-a

# Look for these messages:
# - "Starting bootstrap process"
# - "Downloading bootstrap configuration"
# - "Bootstrap completed successfully"
```

## 🔄 CI/CD Integration

### GitHub Actions Workflows

This repository includes two automated workflows:

#### 1. Validate Workflow (`.github/workflows/validate.yml`)

Runs on every PR:
- ✅ Terraform format check
- ✅ Terraform validate
- ✅ Security scanning (Checkov, tfsec)
- ✅ Compliance checks (mandatory tags, naming conventions)
- ✅ Documentation validation
- ✅ Cost estimation

#### 2. Deploy Workflow (`.github/workflows/deploy.yml`)

Runs on merge to main or manual trigger:
- ✅ Lint and validate
- ✅ Security scan
- ✅ Terraform plan with PR comment
- ✅ Terraform apply (with approval)
- ✅ Upload bootstrap files to GCS
- ✅ Deployment validation

### Setup GitHub Secrets

Required secrets in GitHub repository settings:

```bash
# GCP Authentication
GCP_SA_KEY              # Service account JSON key
GCP_PROJECT_ID          # Project ID

# Palo Alto Credentials
PALO_VM_AUTH_KEY        # VM auth key for Panorama
PALO_AUTH_CODES         # JSON map of auth codes
```

### Manual Workflow Trigger

```bash
# Via GitHub UI: Actions → Deploy → Run workflow
# Or via gh CLI:
gh workflow run deploy.yml \
  -f environment=prod \
  -f action=plan
```

### Integration with Carrier LZ Pipeline

The workflows are designed to integrate with Carrier's existing LZ pipeline:

1. **Terraform State:** Stored in GCS bucket `carrier-terraform-state`
2. **Mandatory Tags:** Automatically applied via locals
3. **Naming Convention:** Uses `prefix` variable
4. **Security Scans:** Checkov and tfsec integrated
5. **Compliance:** Validated in CI/CD

## 🎯 Post-Deployment

### 1. Verify Firewall Access

```bash
# Get management IPs
terraform output firewall_pairs

# Test SSH access
ssh admin@<MGMT_IP>

# Test HTTPS access (use browser or curl)
curl -k https://<MGMT_IP>
```

Default credentials: `admin` / `admin` (change immediately!)

### 2. Configure High Availability

Access each firewall pair via GUI or CLI:

#### Via GUI:

1. Log into first firewall: `https://<FW-01-MGMT-IP>`
2. Navigate to **Device → High Availability → General**
3. Click **Setup** and configure:
   - Enable HA: ✅
   - Group ID: `1` (same for both firewalls)
   - Mode: `Active-Active`
   - Device ID: `0` (for FW-01), `1` (for FW-02)
   - Config Sync: ✅ Enable
4. Configure **HA1 (Control Link)**:
   - Port: `management` (or dedicated HA port)
   - IP Address: Management IP of peer
   - Netmask: Subnet mask
5. Configure **HA2 (Data Link)**:
   - Port: `ethernet1/3` (nic3)
   - Transport: `UDP`
   - IP Address: HA subnet IP
6. Configure **HA3 (Packet Forwarding)**:
   - Enable on `ethernet1/3`
7. **Commit** changes
8. Repeat on second firewall (FW-02) with Device ID `1`

#### Via CLI:

```bash
# On FW-01
configure
set deviceconfig high-availability enabled yes
set deviceconfig high-availability group 1
set deviceconfig high-availability mode active-active
set deviceconfig high-availability device-id 0
set deviceconfig high-availability interface ha1 port management
set deviceconfig high-availability interface ha2 port ethernet1/3 transport udp
set deviceconfig high-availability interface ha3 port ethernet1/3
commit

# On FW-02 (change device-id to 1)
configure
set deviceconfig high-availability device-id 1
# ... (repeat other commands)
commit
```

### 3. Verify HA Status

```bash
# CLI command
show high-availability state

# Expected output:
# State: active-active
# Peer state: active
# Running sync: synchronized
```

### 4. Configure Panorama (StrataCom)

If not using bootstrap VM auth key, manually register:

```bash
# On firewall CLI
request panorama register \
  panorama-server panorama.carrier-global-security.internal \
  auth-key <VM-AUTH-KEY>

# Verify connection
show panorama status
```

In Panorama:
1. Navigate to **Panorama → Managed Devices**
2. Verify firewalls appear as "connected"
3. Push template and device group configs
4. Commit changes

### 5. Configure Load Balancer Health Checks

Create a management profile on firewalls to allow health checks:

```bash
# On firewall
configure
set network profiles interface-management-profile health-check-profile ping yes https yes
set network interface ethernet1/1 layer3 interface-management-profile health-check-profile
commit
```

### 6. Test Traffic Flow

#### External Traffic (North-South):

```bash
# Get external LB IP
terraform output | grep external

# Test connectivity
curl http://<EXTERNAL_LB_IP>
```

#### Internal Traffic (East-West):

```bash
# From internal VM, test routing through firewall
ping <INTERNAL_LB_IP>
traceroute <DESTINATION>
```

### 7. Enable Logging

Configure log forwarding to Google SecOps or Cloud Logging:

**Via Panorama:**
1. **Device → Log Settings → Syslog**
2. Add server profile:
   - Name: `google-secops`
   - Server: `<SecOps-SYSLOG-IP>`
   - Transport: `UDP` or `TCP`
   - Port: `514` or `601`
   - Format: `IETF`
   - Facility: `LOG_USER`
3. Apply to log forwarding profiles
4. Commit and push

### 8. Apply Security Policies

Push security policies from Panorama:

- **Security Rules:** Define allow/deny rules
- **NAT Policies:** Configure source/destination NAT
- **Security Profiles:** Apply threat prevention, anti-virus, URL filtering
- **Application Filters:** Control application usage
- **QoS Policies:** Traffic shaping and prioritization

### 9. Enable Monitoring

Set up monitoring and alerting:

**Cloud Monitoring:**
```bash
# View firewall metrics
gcloud monitoring time-series list \
  --filter='metric.type="compute.googleapis.com/instance/cpu/utilization" AND resource.labels.instance_name=~"carrier-fw.*"'
```

**Palo Alto Native Monitoring:**
- Dashboard: `https://<MGMT_IP>/dashboard`
- CLI: `show system resources`, `show session info`

### 10. Backup Configuration

```bash
# Export configuration
scp admin@<MGMT_IP>:config/running-config.xml ./backup/

# Or use Panorama scheduled backups
```

## 🔧 Troubleshooting

### Bootstrap Issues

**Problem:** Firewall not bootstrapping

**Solutions:**
```bash
# 1. Check bucket permissions
gsutil iam get gs://carrier-palo-bootstrap-1/

# 2. Verify service account has storage.objectViewer
gcloud projects get-iam-policy carrier-global-security-project \
  --flatten="bindings[].members" \
  --filter="bindings.members:serviceAccount:carrier-palo-alto-fw-sa@*"

# 3. Check serial console logs
gcloud compute instances get-serial-port-output carrier-fw-region1-01 \
  --zone=us-central1-a | grep -i bootstrap

# 4. Verify metadata
gcloud compute instances describe carrier-fw-region1-01 \
  --zone=us-central1-a \
  --format="value(metadata.items.vmseries-bootstrap-gce-storagebucket)"

# 5. Check init-cfg.txt syntax
cat bootstrap-files/region1-fw01/config/init-cfg.txt | grep -E "^(type|hostname|panorama-server|authcode)="
```

### HA Not Synchronizing

**Problem:** HA peers not syncing

**Solutions:**
```bash
# Check HA status
show high-availability state
show high-availability interface

# Verify network connectivity
ping management-interface <PEER_IP>

# Check HA2 link
show high-availability state | match ha2

# Force sync
request high-availability sync-to-remote running-config

# Check firewall rules allow HA traffic
gcloud compute firewall-rules list --filter="name~palo-ha"
```

### Load Balancer Health Check Failing

**Problem:** Backend unhealthy in load balancer

**Solutions:**
```bash
# 1. Check health check configuration
gcloud compute health-checks describe carrier-palo-ext-health-1

# 2. Verify firewall allows health check IPs (35.191.0.0/16, 130.211.0.0/22)
gcloud compute firewall-rules describe carrier-allow-palo-health-check

# 3. Check management profile on interface
show network interface

# 4. Test health check manually from GCP health check IP range
curl -k https://<FIREWALL_UNTRUST_IP>:443

# 5. Check firewall system logs
tail follow yes mp-log system.log
```

### Panorama Registration Failing

**Problem:** Firewall not registering with Panorama

**Solutions:**
```bash
# 1. Verify Panorama connectivity
ping panorama.carrier-global-security.internal

# 2. Check DNS resolution
nslookup panorama.carrier-global-security.internal

# 3. Verify VM auth key
show deviceconfig setting management
# Look for panorama-server and vm-auth-key

# 4. Manually register
request panorama register \
  panorama-server panorama.carrier-global-security.internal \
  auth-key <VM-AUTH-KEY>

# 5. Check Panorama logs
# On Panorama: Monitor → Logs → System
```

### License Activation Issues

**Problem:** Auth code not activating

**Solutions:**
```bash
# 1. Check license status
request license info

# 2. Manually activate
request license fetch auth-code <AUTH_CODE>

# 3. Verify internet connectivity
ping 8.8.8.8

# 4. Check Palo Alto licensing server access
ping licenseapi.paloaltonetworks.com

# 5. Deactivate and reactivate
request license deactivate VM-SERIES
request license fetch auth-code <AUTH_CODE>
```

### Terraform Errors

**Problem:** Terraform apply fails

**Solutions:**
```bash
# 1. Check API enablement
gcloud services list --enabled --project=carrier-global-security-project

# 2. Verify permissions
gcloud projects get-iam-policy carrier-global-security-project

# 3. Check quota limits
gcloud compute project-info describe \
  --project=carrier-global-security-project \
  --format="table(quotas:format='table(metric,limit,usage)')"

# 4. Validate Terraform configuration
terraform validate
terraform fmt -check

# 5. Check state file
terraform state list
terraform state show google_compute_instance.firewall[\"1-0\"]

# 6. Enable detailed logging
export TF_LOG=DEBUG
terraform apply
```

### Network Connectivity Issues

**Problem:** Traffic not routing through firewalls

**Solutions:**
```bash
# 1. Check routes in VPC
gcloud compute routes list \
  --filter="network:global-security-vpc-trust"

# 2. Verify load balancer forwarding rules
gcloud compute forwarding-rules describe carrier-palo-int-fwd-1 \
  --region=us-central1

# 3. Check firewall interface IPs
gcloud compute instances describe carrier-fw-region1-01 \
  --zone=us-central1-a \
  --format="table(networkInterfaces[].networkIP)"

# 4. Verify security policies on firewall
show running security-policy-rule

# 5. Check session table
show session all
```

### Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| "Bootstrap failed: unable to access bucket" | Service account permissions | Grant storage.objectViewer role |
| "HA peer not reachable" | Network configuration | Check HA subnet and firewall rules |
| "Health check timeout" | Management profile missing | Configure management profile with ping/https |
| "License activation failed" | Auth code invalid/used | Verify auth code, check Palo Alto support portal |
| "Panorama connection timeout" | Network/DNS issue | Verify Panorama IP/FQDN and network connectivity |

## 🔒 Security Best Practices

### 1. Credential Management

- ❌ Never commit secrets to Git
- ✅ Use GitHub Secrets for CI/CD
- ✅ Use GCP Secret Manager for runtime secrets
- ✅ Rotate admin passwords immediately after deployment
- ✅ Use strong SSH keys (4096-bit RSA or Ed25519)

### 2. Network Segmentation

- ✅ Separate management network from data networks
- ✅ Restrict management access to corporate IP ranges only
- ✅ Use VPN or IAP for remote management access
- ✅ Enable Private Google Access for internal communication

### 3. IAM and Permissions

- ✅ Follow principle of least privilege
- ✅ Use service accounts instead of user accounts
- ✅ Enable audit logging for all IAM changes
- ✅ Regularly review and audit permissions

### 4. Firewall Hardening

- ✅ Change default admin password
- ✅ Disable unused services
- ✅ Enable certificate-based authentication
- ✅ Configure session timeouts
- ✅ Enable administrator role separation

### 5. Logging and Monitoring

- ✅ Forward all logs to central SIEM (Google SecOps)
- ✅ Enable VPC Flow Logs
- ✅ Configure Cloud Monitoring alerts
- ✅ Enable Security Command Center
- ✅ Regular log review and analysis

### 6. Updates and Patching

- ✅ Subscribe to Palo Alto security advisories
- ✅ Test updates in dev/staging before production
- ✅ Maintain update schedule (monthly recommended)
- ✅ Keep content updates current (daily/weekly)

## 📊 Monitoring and Alerting

### Cloud Monitoring Dashboards

Create custom dashboards for:

1. **Firewall Health:**
   - CPU utilization
   - Memory usage
   - Disk usage
   - Session count
   - Throughput

2. **Load Balancer Metrics:**
   - Request count
   - Latency
   - Error rate
   - Backend health

3. **Network Metrics:**
   - Bytes sent/received
   - Packet count
   - Drop rate

### Alerting Policies

Configure alerts for:

```yaml
# Example alert policy (YAML)
displayName: "Palo Alto Firewall CPU High"
conditions:
  - displayName: "CPU > 80%"
    conditionThreshold:
      filter: |
        metric.type="compute.googleapis.com/instance/cpu/utilization"
        resource.type="gce_instance"
        metadata.user_labels.application="palo-alto-firewall"
      comparison: COMPARISON_GT
      thresholdValue: 0.8
      duration: 300s
notificationChannels:
  - projects/carrier-global-security-project/notificationChannels/email-security-team
```

### Log-Based Metrics

Create log-based metrics for security events:

```bash
# Example: Track failed login attempts
gcloud logging metrics create failed_login_attempts \
  --description="Failed admin login attempts to Palo Alto firewalls" \
  --log-filter='resource.type="gce_instance"
    labels.application="palo-alto-firewall"
    "failed authentication"'
```

## 🔄 Maintenance

### Regular Maintenance Tasks

**Weekly:**
- ✅ Review firewall logs for anomalies
- ✅ Check HA status
- ✅ Verify load balancer health
- ✅ Update content (AV, threat prevention)

**Monthly:**
- ✅ Review and update security policies
- ✅ Analyze traffic reports
- ✅ Check for PAN-OS updates
- ✅ Review Cloud Monitoring metrics
- ✅ Audit user access

**Quarterly:**
- ✅ Conduct security assessment
- ✅ Review and test disaster recovery
- ✅ Update documentation
- ✅ Review and optimize cost

**Annually:**
- ✅ Major version upgrades (if needed)
- ✅ License renewals
- ✅ Architecture review
- ✅ Compliance audit

### Upgrade Procedures

#### Content Updates (Weekly):

```bash
# CLI method
request content upgrade download latest

# Verify download
request content upgrade status

# Install
request content upgrade install version latest

# Verify
show system info | match content
```

#### PAN-OS Upgrades (Quarterly):

```bash
# Download new version
request system software download version 11.2.9

# Check download
request system software status

# Install (schedule maintenance window)
request system software install version 11.2.9

# Reboot
request restart system

# Verify
show system info
```

**Best Practice:** Always upgrade one firewall at a time in an HA pair.

### Backup and Disaster Recovery

#### Configuration Backups:

```bash
# Automated via Panorama (recommended)
# Panorama → Device → Scheduled Config Export

# Manual backup
scp admin@<MGMT_IP>:config/running-config.xml \
  ./backups/carrier-fw-region1-01-$(date +%Y%m%d).xml

# Backup Terraform state
gsutil cp gs://carrier-terraform-state/palo-alto/bootstrap/default.tfstate \
  ./backups/terraform-state-$(date +%Y%m%d).tfstate
```

#### Disaster Recovery:

1. **Complete Region Failure:**
   - Traffic automatically rerouted to other regions
   - Deploy new firewalls using Terraform
   - Restore configuration from Panorama

2. **Single Firewall Failure:**
   - HA peer takes over immediately
   - Replace failed instance via Terraform
   - Re-sync configuration from HA peer

3. **Panorama Failure:**
   - Firewalls continue with last known config
   - Restore Panorama from backup
   - Re-establish connections

## 📞 Support

### Internal Support

- **Security Team:** security-team@carrier.com
- **Cloud Platform Team:** cloud-ops@carrier.com
- **Slack Channel:** #palo-alto-firewalls

### External Support

- **Palo Alto Networks Support:** https://support.paloaltonetworks.com/
- **Support Phone:** 1-866-898-9087
- **TAC Cases:** Open via customer portal

### Documentation

- **Palo Alto VM-Series Docs:** https://docs.paloaltonetworks.com/vm-series
- **GCP Load Balancing:** https://cloud.google.com/load-balancing/docs
- **Terraform Google Provider:** https://registry.terraform.io/providers/hashicorp/google/

## 📜 License

Copyright 2025 Carrier Project. All rights reserved.

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development guidelines.

## 📝 Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.

---

**Maintained by:** Carrier Cloud Security Team  
**Last Updated:** December 31, 2025  
**Version:** 1.0.0
