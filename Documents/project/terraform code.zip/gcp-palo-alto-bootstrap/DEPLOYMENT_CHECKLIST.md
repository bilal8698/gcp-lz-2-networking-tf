# Carrier Palo Alto Bootstrap - Deployment Checklist

Use this checklist to ensure all steps are completed for successful deployment.

## Pre-Deployment

### GCP Environment

- [ ] GCP project created: `carrier-global-security-project`
- [ ] Billing enabled on project
- [ ] Required APIs enabled:
  - [ ] Compute Engine API
  - [ ] Cloud Resource Manager API
  - [ ] Cloud Logging API
  - [ ] IAM API
  - [ ] Cloud Storage API
- [ ] Service account created with required roles:
  - [ ] `roles/compute.admin`
  - [ ] `roles/storage.admin`
  - [ ] `roles/iam.serviceAccountAdmin`
  - [ ] `roles/logging.admin`
- [ ] VPC networks exist:
  - [ ] `global-security-vpc-mgmt`
  - [ ] `global-security-vpc-untrust`
  - [ ] `global-security-vpc-trust`
  - [ ] `global-security-vpc-ha`
- [ ] Subnets created in all 3 regions for each VPC
- [ ] IAM permissions verified

### Palo Alto Requirements

- [ ] Palo Alto support account active
- [ ] VM-Series licenses obtained (6 total)
- [ ] Auth codes documented (kept secure)
- [ ] Panorama (StrataCom) instance deployed and configured
- [ ] VM auth key for Panorama obtained
- [ ] Template created in Panorama: `Carrier-VM-Series-Template`
- [ ] Device groups created:
  - [ ] `Carrier-Region1-DG`
  - [ ] `Carrier-Region2-DG`
  - [ ] `Carrier-Region3-DG`

### Bootstrap Files Downloaded

- [ ] Content updates downloaded:
  - [ ] Anti-virus signatures (panup-all-antivirus-*)
  - [ ] Threat content (panupv2-all-contents-*)
  - [ ] WildFire updates (panup-all-wildfire-*)
- [ ] PAN-OS software downloaded: `PanOS_vm-11.2.8`
- [ ] VM-Series plugin downloaded: `vm_series-2.0.2`
- [ ] License files prepared

### Local Environment

- [ ] Terraform installed (>= 1.5.0)
- [ ] gcloud CLI installed and configured
- [ ] Git repository cloned
- [ ] SSH key pair generated for firewall access
- [ ] Text editor/IDE configured

## Configuration

### Terraform Variables

- [ ] Copied `terraform.tfvars.example` to `terraform.tfvars`
- [ ] Updated `project_id`
- [ ] Updated `prefix`
- [ ] Updated mandatory tags:
  - [ ] `cost_center`
  - [ ] `owner`
  - [ ] `leanix_app_id`
- [ ] Configured `firewall_regions` (3 regions)
- [ ] Updated Panorama configuration:
  - [ ] `panorama_server`
  - [ ] `panorama_server_2`
  - [ ] `panorama_template_name`
- [ ] Verified network names match existing VPCs
- [ ] Added SSH public keys
- [ ] Configured `allowed_mgmt_cidrs` (restricted to internal networks)

### Bootstrap init-cfg.txt Files

For each of 6 firewalls:

- [ ] Region 1 - FW01: Updated init-cfg.txt
  - [ ] Replaced `REPLACE_WITH_LICENSE_AUTH_CODE`
  - [ ] Replaced `REPLACE_WITH_ACTUAL_VM_AUTH_KEY`
  - [ ] Verified hostname: `carrier-fw-region1-01`
  - [ ] Verified Panorama servers
- [ ] Region 1 - FW02: Updated init-cfg.txt
  - [ ] Replaced auth code
  - [ ] Replaced VM auth key
  - [ ] Verified hostname: `carrier-fw-region1-02`
- [ ] Region 2 - FW01: Updated init-cfg.txt
  - [ ] Replaced auth code
  - [ ] Replaced VM auth key
  - [ ] Verified hostname: `carrier-fw-region2-01`
- [ ] Region 2 - FW02: Updated init-cfg.txt
  - [ ] Replaced auth code
  - [ ] Replaced VM auth key
  - [ ] Verified hostname: `carrier-fw-region2-02`
- [ ] Region 3 - FW01: Updated init-cfg.txt
  - [ ] Replaced auth code
  - [ ] Replaced VM auth key
  - [ ] Verified hostname: `carrier-fw-region3-01`
- [ ] Region 3 - FW02: Updated init-cfg.txt
  - [ ] Replaced auth code
  - [ ] Replaced VM auth key
  - [ ] Verified hostname: `carrier-fw-region3-02`

### Bootstrap Content Files

- [ ] Placed content files in `bootstrap-files/region1-fw01/content/`
- [ ] Placed software in `bootstrap-files/region1-fw01/software/`
- [ ] Created authcodes file in `bootstrap-files/region1-fw01/license/`
- [ ] Placed plugin in `bootstrap-files/region1-fw01/plugins/`
- [ ] Files will be copied to other regions automatically

### GitHub Repository (if using CI/CD)

- [ ] Repository created in GitHub Enterprise
- [ ] Secrets configured:
  - [ ] `GCP_SA_KEY`
  - [ ] `GCP_PROJECT_ID`
  - [ ] `PALO_VM_AUTH_KEY`
- [ ] Branch protection rules configured
- [ ] Required reviewers assigned

## Deployment

### Terraform Deployment

- [ ] Authenticated to GCP: `gcloud auth application-default login`
- [ ] Changed to terraform directory: `cd terraform`
- [ ] Ran `terraform init` successfully
- [ ] Ran `terraform validate` successfully
- [ ] Ran `terraform fmt -recursive`
- [ ] Ran `terraform plan` and reviewed output
- [ ] Ran `terraform apply` and approved
- [ ] Terraform apply completed without errors
- [ ] Reviewed terraform outputs

### Bootstrap File Upload

- [ ] Obtained bucket names from terraform output
- [ ] Uploaded files to Region 1 bucket
- [ ] Uploaded files to Region 2 bucket
- [ ] Uploaded files to Region 3 bucket
- [ ] Verified files in buckets: `gsutil ls -r gs://bucket-name/`

### Instance Verification

- [ ] All 6 firewall instances created
- [ ] All instances running: `gcloud compute instances list`
- [ ] Reviewed serial console logs for bootstrap progress
- [ ] No errors in serial console
- [ ] Bootstrap completed (allow 10-15 minutes)

## Post-Deployment Configuration

### Firewall Access

- [ ] Obtained management IP addresses from terraform output
- [ ] SSH access tested to all 6 firewalls
- [ ] HTTPS GUI access tested
- [ ] Changed default admin password on all firewalls
- [ ] Verified PAN-OS version
- [ ] Verified license activation

### High Availability Setup

Region 1:
- [ ] Configured HA on FW-01 (Device ID 0)
- [ ] Configured HA on FW-02 (Device ID 1)
- [ ] HA status shows "active-active"
- [ ] Config sync enabled and working
- [ ] HA2 link operational
- [ ] HA3 link operational
- [ ] Tested failover

Region 2:
- [ ] Configured HA on FW-01 (Device ID 0)
- [ ] Configured HA on FW-02 (Device ID 1)
- [ ] HA status verified
- [ ] Config sync working
- [ ] Tested failover

Region 3:
- [ ] Configured HA on FW-01 (Device ID 0)
- [ ] Configured HA on FW-02 (Device ID 1)
- [ ] HA status verified
- [ ] Config sync working
- [ ] Tested failover

### Panorama Integration

- [ ] All 6 firewalls registered with Panorama
- [ ] Firewall status shows "Connected" in Panorama
- [ ] Template assigned to firewalls
- [ ] Device groups assigned
- [ ] Initial configuration pushed from Panorama
- [ ] Verified configuration applied successfully

### Load Balancers

- [ ] External load balancers created (3 total)
- [ ] Internal load balancers created (3 total)
- [ ] Health checks passing for all backends
- [ ] Backend services show healthy instances
- [ ] Tested traffic flow through external LB
- [ ] Tested traffic flow through internal LB

### Network Configuration

- [ ] Management profiles configured on interfaces
- [ ] Untrust interfaces configured
- [ ] Trust interfaces configured
- [ ] HA interfaces configured
- [ ] Default routes configured
- [ ] Inter-zone routing enabled

### Security Configuration

- [ ] Security zones defined
- [ ] Security policies applied
- [ ] NAT policies configured
- [ ] Application filters configured
- [ ] Security profiles applied:
  - [ ] Anti-virus
  - [ ] Anti-spyware
  - [ ] Vulnerability protection
  - [ ] URL filtering
  - [ ] File blocking
  - [ ] WildFire analysis
- [ ] Tested policy enforcement

### Logging and Monitoring

- [ ] Log forwarding configured to Google SecOps
- [ ] Tested log forwarding
- [ ] Cloud Monitoring dashboards created
- [ ] Alerting policies configured:
  - [ ] High CPU usage
  - [ ] High memory usage
  - [ ] Health check failures
  - [ ] HA failover events
  - [ ] License expiration
- [ ] VPC Flow Logs enabled
- [ ] Cloud Logging verified

## Testing

### Connectivity Tests

- [ ] Tested internet egress through firewalls
- [ ] Tested east-west traffic through firewalls
- [ ] Tested policy enforcement
- [ ] Tested NAT functionality
- [ ] Tested load balancer distribution
- [ ] Verified session distribution across HA pair

### Failover Tests

- [ ] Simulated firewall failure in Region 1
- [ ] Verified automatic failover to HA peer
- [ ] Verified traffic continuity
- [ ] Tested manual failover
- [ ] Restored failed firewall
- [ ] Verified HA synchronization

### Performance Tests

- [ ] Measured baseline throughput
- [ ] Tested concurrent sessions
- [ ] Verified latency is acceptable
- [ ] No packet loss observed
- [ ] Resource utilization within normal ranges

## Documentation

- [ ] Updated network diagrams with firewall IPs
- [ ] Documented admin credentials (in secure vault)
- [ ] Created runbook for common operations
- [ ] Updated disaster recovery procedures
- [ ] Documented HA failover procedures
- [ ] Created troubleshooting guide

## Backup and DR

- [ ] Configuration backed up from all firewalls
- [ ] Terraform state backed up
- [ ] Bootstrap files backed up
- [ ] Disaster recovery plan documented
- [ ] Disaster recovery tested

## Security Hardening

- [ ] Default passwords changed
- [ ] Unnecessary services disabled
- [ ] Management access restricted to internal IPs only
- [ ] SSH keys configured (password auth disabled)
- [ ] Session timeouts configured
- [ ] Role-based access control configured
- [ ] Audit logging enabled
- [ ] Certificate-based authentication configured (optional)

## Compliance

- [ ] All resources tagged with mandatory labels:
  - [ ] `cost_center`
  - [ ] `owner`
  - [ ] `application`
  - [ ] `leanix_app_id`
  - [ ] `managed-by`
- [ ] Resources follow Carrier naming convention
- [ ] Security scans passed (Checkov, tfsec)
- [ ] Compliance requirements met
- [ ] Documented in LeanIX

## Handoff

- [ ] Operations team trained
- [ ] Access credentials provided to appropriate teams
- [ ] Documentation shared
- [ ] Monitoring access configured
- [ ] On-call procedures documented
- [ ] Escalation paths defined

## Sign-Off

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Project Lead | | | |
| Security Lead | | | |
| Cloud Architect | | | |
| Operations Lead | | | |

---

**Deployment Date:** _______________  
**Environment:** Production  
**Project:** Carrier Palo Alto VM-Series Bootstrap  
**Version:** 1.0.0
