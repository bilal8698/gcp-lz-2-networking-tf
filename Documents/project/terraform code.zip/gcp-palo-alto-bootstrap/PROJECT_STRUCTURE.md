# Project Structure

```
gcp-palo-alto-bootstrap/
│
├── README.md                          # Main documentation
├── QUICK_REFERENCE.md                 # Quick command reference
├── DEPLOYMENT_CHECKLIST.md            # Deployment checklist
├── CHANGELOG.md                       # Version history
├── .gitignore                         # Git ignore rules
│
├── bootstrap-files/                   # Bootstrap configuration files
│   ├── region1-fw01/
│   │   ├── config/
│   │   │   └── init-cfg.txt          # Bootstrap config for FW-01
│   │   ├── content/
│   │   │   └── README.md             # Instructions for content files
│   │   ├── software/
│   │   │   └── README.md             # Instructions for PAN-OS software
│   │   ├── license/
│   │   │   └── README.md             # Instructions for licenses
│   │   └── plugins/
│   │       └── README.md             # Instructions for VM plugins
│   │
│   ├── region1-fw02/
│   │   ├── config/
│   │   │   └── init-cfg.txt          # Bootstrap config for FW-02
│   │   ├── content/
│   │   ├── software/
│   │   ├── license/
│   │   └── plugins/
│   │
│   ├── region2-fw01/
│   │   ├── config/
│   │   │   └── init-cfg.txt          # Bootstrap config for region 2 FW-01
│   │   ├── content/
│   │   ├── software/
│   │   ├── license/
│   │   └── plugins/
│   │
│   ├── region2-fw02/
│   │   ├── config/
│   │   │   └── init-cfg.txt          # Bootstrap config for region 2 FW-02
│   │   ├── content/
│   │   ├── software/
│   │   ├── license/
│   │   └── plugins/
│   │
│   ├── region3-fw01/
│   │   ├── config/
│   │   │   └── init-cfg.txt          # Bootstrap config for region 3 FW-01
│   │   ├── content/
│   │   ├── software/
│   │   ├── license/
│   │   └── plugins/
│   │
│   └── region3-fw02/
│       ├── config/
│       │   └── init-cfg.txt          # Bootstrap config for region 3 FW-02
│       ├── content/
│       ├── software/
│       ├── license/
│       └── plugins/
│
├── terraform/                         # Terraform infrastructure code
│   ├── main.tf                        # Main Terraform configuration
│   ├── variables.tf                   # Variable definitions
│   ├── outputs.tf                     # Output definitions
│   ├── firewalls.tf                   # VM-Series firewall resources
│   ├── load-balancers.tf              # Load balancer resources
│   ├── terraform.tfvars.example       # Example variables file
│   └── terraform.tfvars               # Actual variables (not in git)
│
└── .github/                           # GitHub Actions CI/CD
    └── workflows/
        ├── deploy.yml                 # Deployment workflow
        └── validate.yml               # Validation workflow
```

## Directory Descriptions

### Root Directory
- **README.md**: Comprehensive documentation covering architecture, setup, deployment, and troubleshooting
- **QUICK_REFERENCE.md**: Quick command reference for common operations
- **DEPLOYMENT_CHECKLIST.md**: Step-by-step checklist for deployment
- **CHANGELOG.md**: Version history and release notes
- **.gitignore**: Excludes sensitive files and large binaries from git

### bootstrap-files/
Contains bootstrap configuration files for all 6 firewalls (2 per region, 3 regions).

Each firewall directory contains:
- **config/init-cfg.txt**: Initial configuration file read during bootstrap
- **content/**: Threat prevention, anti-virus, and WildFire updates (user must add)
- **software/**: PAN-OS software images for upgrades (user must add)
- **license/**: License files and auth codes (user must add)
- **plugins/**: VM-Series plugins (user must add)

Files in content/, software/, license/, and plugins/ must be downloaded from Palo Alto Networks Support Portal and are not included in the repository due to size and licensing.

### terraform/
Contains all Infrastructure as Code (IaC) for deploying the bootstrap infrastructure.

- **main.tf**: Core Terraform configuration including:
  - Provider configuration
  - GCS bucket creation for bootstrap files
  - Bootstrap file uploads
  - Service account creation
  - IAM permissions

- **variables.tf**: Defines all input variables:
  - Project configuration
  - Region settings
  - Network configuration
  - HA settings
  - Security settings
  - Carrier mandatory tags

- **outputs.tf**: Defines outputs including:
  - Bootstrap bucket names
  - Service account information
  - Firewall configuration
  - Deployment instructions

- **firewalls.tf**: VM-Series firewall resources:
  - Compute instances
  - Instance groups
  - Network interfaces
  - Firewall rules
  - Metadata configuration

- **load-balancers.tf**: Load balancing resources:
  - External load balancers (3)
  - Internal load balancers (3)
  - Health checks
  - Backend services
  - Forwarding rules
  - Cloud Armor policies

- **terraform.tfvars.example**: Example configuration file
- **terraform.tfvars**: Actual configuration (excluded from git, must be created)

### .github/workflows/
GitHub Actions CI/CD pipelines for automated deployment and validation.

- **deploy.yml**: Main deployment workflow
  - Terraform validation
  - Security scanning
  - Terraform plan with PR comments
  - Terraform apply (with approval)
  - Bootstrap file upload
  - Deployment validation

- **validate.yml**: Validation workflow for PRs
  - Code quality checks
  - Terraform validation
  - Security scanning
  - Compliance checks
  - Documentation validation

## File Sizes

Typical file sizes (for planning storage/bandwidth):

| File Type | Size | Location |
|-----------|------|----------|
| init-cfg.txt | ~2 KB | bootstrap-files/*/config/ |
| Anti-virus content | ~50-100 MB | bootstrap-files/*/content/ |
| Threat content | ~100-200 MB | bootstrap-files/*/content/ |
| WildFire updates | ~50-100 MB | bootstrap-files/*/content/ |
| PAN-OS software | ~400-600 MB | bootstrap-files/*/software/ |
| VM-Series plugin | ~5-10 MB | bootstrap-files/*/plugins/ |
| License files | ~1 KB each | bootstrap-files/*/license/ |

Total storage needed per region: ~600-1000 MB

## Git Repository Size

Without binary files (using .gitignore):
- Repository size: ~1-2 MB (code and configs only)
- With documentation: ~2-3 MB

With all binary files (not recommended):
- Repository size: ~3-5 GB
- GitHub has 100 MB file size limit, so large files cannot be committed

## Deployment Flow

1. **Code Repository** → GitHub
2. **Bootstrap Files** → Download from Palo Alto, store locally
3. **Terraform** → Create GCS buckets
4. **Upload** → Bootstrap files to GCS buckets
5. **Terraform** → Deploy VM-Series instances
6. **Bootstrap** → Instances download config from GCS
7. **Panorama** → Firewalls register and receive config
8. **HA Configuration** → Manual setup via GUI/CLI
9. **Testing** → Verify deployment
10. **Production** → Traffic flows through firewalls

## Key Files to Customize

Before deployment, update these files:

1. **terraform/terraform.tfvars**
   - Project ID
   - Mandatory tags (cost_center, owner, leanix_app_id)
   - Regions and zones
   - Network names
   - Panorama servers
   - SSH keys
   - Allowed management CIDRs

2. **bootstrap-files/region*-fw*/config/init-cfg.txt** (all 6 files)
   - Auth codes (licensing)
   - VM auth key (Panorama registration)
   - IP addresses (if using static IPs)
   - Hostname (already set appropriately)
   - Panorama servers (already set appropriately)

3. **.github/workflows/deploy.yml** (if using CI/CD)
   - GCP project ID
   - Bucket name for Terraform state
   - Notification channels

## Security Considerations

**DO NOT commit to git:**
- terraform.tfvars (contains project-specific config)
- License files and auth codes
- VM auth keys
- Service account keys
- SSH private keys
- Any .key, .pem, .p12 files

**DO commit to git:**
- terraform.tfvars.example (template)
- All Terraform .tf files
- init-cfg.txt templates (with placeholders)
- README files
- CI/CD workflows

## Backup Strategy

Recommended backups:
1. **Terraform state**: Automatically backed up in GCS
2. **Bootstrap files**: Back up to secure storage
3. **Firewall configs**: Export from Panorama regularly
4. **License files**: Store securely, separate from code
5. **Documentation**: Keep in git

---

**Last Updated:** December 31, 2025  
**Maintained By:** Carrier Cloud Security Team
