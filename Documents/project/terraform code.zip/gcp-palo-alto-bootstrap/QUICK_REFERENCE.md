# Palo Alto Bootstrap - Quick Reference

## 🚀 Common Commands

### Terraform Operations

```bash
# Initialize
cd terraform && terraform init

# Format code
terraform fmt -recursive

# Validate
terraform validate

# Plan
terraform plan -out=tfplan

# Apply
terraform apply tfplan

# Destroy (careful!)
terraform destroy

# Show outputs
terraform output

# Show specific output
terraform output bootstrap_bucket_names
```

### GCS Bucket Operations

```bash
# List buckets
gsutil ls | grep palo-bootstrap

# List bucket contents
gsutil ls -r gs://carrier-palo-bootstrap-1/

# Upload file
gsutil cp local-file.txt gs://carrier-palo-bootstrap-1/config/

# Upload directory
gsutil -m rsync -r local-dir/ gs://carrier-palo-bootstrap-1/

# Download file
gsutil cp gs://carrier-palo-bootstrap-1/config/init-cfg.txt ./

# Set permissions
gsutil iam ch serviceAccount:sa@project.iam.gserviceaccount.com:objectViewer \
  gs://carrier-palo-bootstrap-1/
```

### GCP Compute Operations

```bash
# List firewalls
gcloud compute instances list \
  --filter="labels.application=palo-alto-firewall"

# Get instance details
gcloud compute instances describe carrier-fw-region1-01 \
  --zone=us-central1-a

# View serial console
gcloud compute instances get-serial-port-output carrier-fw-region1-01 \
  --zone=us-central1-a

# SSH to instance
gcloud compute ssh carrier-fw-region1-01 \
  --zone=us-central1-a

# Stop instance
gcloud compute instances stop carrier-fw-region1-01 \
  --zone=us-central1-a

# Start instance
gcloud compute instances start carrier-fw-region1-01 \
  --zone=us-central1-a

# Delete instance
gcloud compute instances delete carrier-fw-region1-01 \
  --zone=us-central1-a
```

### Load Balancer Operations

```bash
# List forwarding rules
gcloud compute forwarding-rules list

# Describe forwarding rule
gcloud compute forwarding-rules describe carrier-palo-ext-fwd-1 \
  --region=us-central1

# Check backend health
gcloud compute backend-services get-health carrier-palo-ext-backend-1 \
  --region=us-central1

# List health checks
gcloud compute health-checks list
```

## 🔥 Firewall CLI Commands

### System Information

```bash
# Show system info
show system info

# Show hostname
show system info | match hostname

# Show PAN-OS version
show system info | match sw-version

# Show uptime
show system info | match uptime

# Show serial number
show system info | match serial

# Show licenses
request license info

# Show resource usage
show system resources
```

### High Availability

```bash
# Show HA status
show high-availability state

# Show HA details
show high-availability all

# Show HA interface
show high-availability interface

# Sync config to peer
request high-availability sync-to-remote running-config

# Force failover
request high-availability state suspend

# Resume from suspended state
request high-availability state functional
```

### Network Operations

```bash
# Show interfaces
show interface all

# Show interface details
show interface ethernet1/1

# Show routing table
show routing route

# Show ARP table
show arp all

# Test connectivity
ping host 8.8.8.8
traceroute host google.com
```

### Session Management

```bash
# Show all sessions
show session all

# Show session count
show session info

# Show sessions for specific IP
show session all filter source 10.0.0.1

# Clear all sessions
clear session all

# Clear sessions for IP
clear session all filter source 10.0.0.1
```

### Configuration

```bash
# Enter configuration mode
configure

# Save configuration
commit

# Show candidate config
show config candidate

# Show running config
show config running

# Compare configs
show config diff

# Load saved config
load config from <filename>

# Save config to file
save config to <filename>

# Revert to previous config
load config from running-config.xml.bak
```

### Logging

```bash
# Show system logs
show log system

# Show traffic logs
show log traffic

# Show threat logs
show log threat

# Filter logs
show log system direction equal backward query \
  "( addr.src in 10.0.0.1 )"

# Tail logs
tail follow yes mp-log system.log
```

### Software/Content Updates

```bash
# Check for updates
request system software check

# Download software
request system software download version 11.2.9

# Install software
request system software install version 11.2.9

# Check content updates
request content upgrade check

# Download content
request content upgrade download latest

# Install content
request content upgrade install version latest
```

### Panorama Operations

```bash
# Show Panorama status
show panorama status

# Register with Panorama
request panorama register \
  panorama-server panorama.example.com \
  auth-key <key>

# Deregister from Panorama
request panorama deregister

# Force sync from Panorama
request system private-data-reset
```

### Troubleshooting

```bash
# Restart management plane
debug software restart process management-server

# Restart data plane
debug dataplane restart all

# Show running processes
show system software status

# Capture packets
debug dataplane packet-diag set capture on

# View packet capture
debug dataplane packet-diag show capture

# Generate tech support file
request tech-support dump

# Test Panorama connectivity
test panorama-connectivity
```

## 📊 Monitoring Commands

### Health Checks

```bash
# Check CPU
show system resources | match cpu

# Check memory
show system resources | match Memory

# Check disk
show system disk-space

# Check session usage
show session info | match rate

# Check dataplane utilization
show running resource-monitor
```

### Performance

```bash
# Show throughput
show counter global filter severity drop

# Show session statistics
show session statistics

# Show interface counters
show counter interface all

# Show global counters
show counter global
```

## 🔧 Common Issues & Fixes

### Issue: Bootstrap not working

```bash
# Check metadata
gcloud compute instances describe INSTANCE_NAME \
  --format="get(metadata.items)"

# Verify bucket access
gsutil ls gs://BUCKET_NAME/

# Check service account
gcloud compute instances describe INSTANCE_NAME \
  --format="get(serviceAccounts[].email)"
```

### Issue: HA not syncing

```bash
# On firewall CLI
show high-availability state
show high-availability interface

# Force sync
request high-availability sync-to-remote running-config

# Check HA2 link
show high-availability state | match ha2
```

### Issue: Health check failing

```bash
# Check management profile
show network interface ethernet1/1 | match management

# Check firewall rules
gcloud compute firewall-rules list --filter="name~health"

# Test manually
curl -k https://FIREWALL_IP:443
```

### Issue: Can't access management

```bash
# Check firewall rules
gcloud compute firewall-rules list --filter="name~mgmt"

# Check instance has external IP
gcloud compute instances describe INSTANCE_NAME \
  --format="get(networkInterfaces[0].accessConfigs[0].natIP)"

# Test connectivity
ping MGMT_IP
telnet MGMT_IP 443
```

## 📝 File Locations

### Bootstrap Files

```
bootstrap-files/
├── region1-fw01/
│   ├── config/init-cfg.txt
│   ├── content/
│   ├── software/
│   ├── license/
│   └── plugins/
├── region1-fw02/
│   └── ...
└── ...
```

### Terraform Files

```
terraform/
├── main.tf
├── variables.tf
├── outputs.tf
├── firewalls.tf
├── load-balancers.tf
├── terraform.tfvars.example
└── terraform.tfvars (not in git)
```

### CI/CD Files

```
.github/workflows/
├── deploy.yml
└── validate.yml
```

## 🔐 Security Checklist

- [ ] Changed default admin password
- [ ] Updated init-cfg.txt with actual values
- [ ] Removed placeholders from configs
- [ ] Added SSH keys
- [ ] Restricted management access CIDR
- [ ] Enabled Cloud Armor (optional)
- [ ] Configured Panorama connection
- [ ] Enabled logging to SecOps
- [ ] Applied security policies
- [ ] Tested failover
- [ ] Backed up configuration
- [ ] Documented access procedures

## 📞 Emergency Contacts

- **Security Team:** security-team@carrier.com
- **Cloud Ops:** cloud-ops@carrier.com
- **Palo Alto TAC:** 1-866-898-9087
- **Slack:** #palo-alto-firewalls

## 🔗 Useful Links

- [Palo Alto VM-Series Docs](https://docs.paloaltonetworks.com/vm-series)
- [GCP Load Balancing](https://cloud.google.com/load-balancing/docs)
- [Terraform Google Provider](https://registry.terraform.io/providers/hashicorp/google/)
- [Palo Alto Support Portal](https://support.paloaltonetworks.com/)

---

**Last Updated:** December 31, 2025
